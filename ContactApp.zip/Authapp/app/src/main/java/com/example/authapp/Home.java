package com.example.authapp;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class Home extends AppCompatActivity {

    EditText etName, etPno, etEmail;
    Button save,logout;
    DatabaseReference Contact;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        etName = findViewById(R.id.etName);
        etPno = findViewById(R.id.etPno);
        etEmail = findViewById(R.id.etEmail);
        save = findViewById(R.id.save);
        logout = findViewById(R.id.logout);

        Contact = FirebaseDatabase.getInstance().getReference().child("Contacts");

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                insertContacts();
            }
        });

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), MainActivity.class));
            }
        });

    }

    private  void insertContacts(){

        String name = etName.getText().toString();
        String pno = etPno.getText().toString();
        String email = etEmail.getText().toString();


        if (TextUtils.isEmpty(name)) {
            etName.setError("Name is required");
            return;
        }

        if (TextUtils.isEmpty(pno)) {
            etPno.setError("Phone number is required");
            return;
        }

        if (TextUtils.isEmpty(email)) {
            etEmail.setError("Email is required");
            return;
        }
        Contacts contacts = new Contacts(name,pno,email);

        Contact.push().setValue(contacts);
        Toast.makeText(Home.this, "Contact Saved", Toast.LENGTH_SHORT).show();
    }


}
