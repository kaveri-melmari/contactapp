package com.example.authapp;

public class Contacts {

    String name;
    String pno;
    String email;

    public Contacts(String name, String pno, String email) {
        this.name = name;
        this.pno = pno;
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public String getPno() {
        return pno;
    }

    public String getEmail() {
        return email;
    }
}

